<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class DataTour extends Model
{

	protected $primaryKey = 'id_tour';

    protected $fillable=['tour', 'gambar_utama', 'paket', 'harga'];
}

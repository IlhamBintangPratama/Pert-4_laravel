<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class DataPasien extends Model
{

	protected $primaryKey = 'id_pasien';

    protected $fillable=['nama_pasien', 'ttl', 'umur', 'jk', 'alamat', 'tgl_datang', 'gejala', 'nama_penyakit', 'nama_obat'];
}
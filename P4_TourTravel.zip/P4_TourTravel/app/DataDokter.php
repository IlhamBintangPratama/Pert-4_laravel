;<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class DataDokter extends Model
{
    //
}

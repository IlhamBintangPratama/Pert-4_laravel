<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\DataTour;

class DataTourController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $datatours = DataTour::latest()->get();
        return view('index', compact('datatours'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $datatour = DataTour::create([
            'tour' => $request->input('tour'),
            'gambar_utama' => $request->input('gambar_utama'),
            'paket' => $request->input('paket'),
            'harga' => $request->input('harga'),
           
        ]);
        return redirect(route('datatours.index'));
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit(DataTour $datatour)
    // ada $id
    {
        return view('edit', compact('datatour'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, DataTour $datatour)
    // ada $id
    {
        $datatour = DataTour::whereid_tour($datatour->id_tour)->update([
            'tour' => $request->input('tour'),
            'gambar_utama' => $request->input('gambar_utama'),
            'paket' => $request->input('paket'),
            'harga' => $request->input('harga'),
        ]);

        return redirect(route('datatours.index'));
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id_tour)
    {
        $datatour = DataTour::find($id_tour);
        $datatour->delete();

        return redirect(route('datatours.index'));
    }
}